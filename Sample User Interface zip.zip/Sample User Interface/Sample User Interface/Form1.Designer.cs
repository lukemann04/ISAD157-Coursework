﻿namespace Sample_User_Interface
{
    partial class DatabaseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcomeName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUserFullName = new System.Windows.Forms.Label();
            this.lblUserGender = new System.Windows.Forms.Label();
            this.lblUserRelationshipStatus = new System.Windows.Forms.Label();
            this.lblHometown = new System.Windows.Forms.Label();
            this.lblUserCurrentCity = new System.Windows.Forms.Label();
            this.lstFriends = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblUserUniversity = new System.Windows.Forms.Label();
            this.lblUserWorkplace = new System.Windows.Forms.Label();
            this.lstMessages = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnEditProfile = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWelcomeName
            // 
            this.lblWelcomeName.AutoSize = true;
            this.lblWelcomeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcomeName.Location = new System.Drawing.Point(221, 9);
            this.lblWelcomeName.Name = "lblWelcomeName";
            this.lblWelcomeName.Size = new System.Drawing.Size(0, 36);
            this.lblWelcomeName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 36);
            this.label2.TabIndex = 2;
            this.label2.Text = "Welcome Back";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 36);
            this.label1.TabIndex = 3;
            this.label1.Text = "Your Profile: ";
            // 
            // lblUserFullName
            // 
            this.lblUserFullName.AutoSize = true;
            this.lblUserFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserFullName.Location = new System.Drawing.Point(18, 333);
            this.lblUserFullName.Name = "lblUserFullName";
            this.lblUserFullName.Size = new System.Drawing.Size(101, 26);
            this.lblUserFullName.TabIndex = 5;
            this.lblUserFullName.Text = "full name";
            // 
            // lblUserGender
            // 
            this.lblUserGender.AutoSize = true;
            this.lblUserGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserGender.Location = new System.Drawing.Point(18, 381);
            this.lblUserGender.Name = "lblUserGender";
            this.lblUserGender.Size = new System.Drawing.Size(79, 26);
            this.lblUserGender.TabIndex = 6;
            this.lblUserGender.Text = "gender";
            // 
            // lblUserRelationshipStatus
            // 
            this.lblUserRelationshipStatus.AutoSize = true;
            this.lblUserRelationshipStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserRelationshipStatus.Location = new System.Drawing.Point(18, 434);
            this.lblUserRelationshipStatus.Name = "lblUserRelationshipStatus";
            this.lblUserRelationshipStatus.Size = new System.Drawing.Size(187, 26);
            this.lblUserRelationshipStatus.TabIndex = 7;
            this.lblUserRelationshipStatus.Text = "relationship status";
            // 
            // lblHometown
            // 
            this.lblHometown.AutoSize = true;
            this.lblHometown.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHometown.Location = new System.Drawing.Point(18, 488);
            this.lblHometown.Name = "lblHometown";
            this.lblHometown.Size = new System.Drawing.Size(113, 26);
            this.lblHometown.TabIndex = 8;
            this.lblHometown.Text = "hometown";
            // 
            // lblUserCurrentCity
            // 
            this.lblUserCurrentCity.AutoSize = true;
            this.lblUserCurrentCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserCurrentCity.Location = new System.Drawing.Point(18, 543);
            this.lblUserCurrentCity.Name = "lblUserCurrentCity";
            this.lblUserCurrentCity.Size = new System.Drawing.Size(118, 26);
            this.lblUserCurrentCity.TabIndex = 9;
            this.lblUserCurrentCity.Text = "current city";
            // 
            // lstFriends
            // 
            this.lstFriends.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstFriends.FormattingEnabled = true;
            this.lstFriends.ItemHeight = 25;
            this.lstFriends.Location = new System.Drawing.Point(531, 149);
            this.lstFriends.Name = "lstFriends";
            this.lstFriends.Size = new System.Drawing.Size(411, 529);
            this.lstFriends.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(525, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 36);
            this.label3.TabIndex = 11;
            this.label3.Text = "Friends List: ";
            // 
            // lblUserUniversity
            // 
            this.lblUserUniversity.AutoSize = true;
            this.lblUserUniversity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserUniversity.Location = new System.Drawing.Point(18, 596);
            this.lblUserUniversity.Name = "lblUserUniversity";
            this.lblUserUniversity.Size = new System.Drawing.Size(172, 26);
            this.lblUserUniversity.TabIndex = 12;
            this.lblUserUniversity.Text = "University: None";
            // 
            // lblUserWorkplace
            // 
            this.lblUserWorkplace.AutoSize = true;
            this.lblUserWorkplace.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserWorkplace.Location = new System.Drawing.Point(18, 650);
            this.lblUserWorkplace.Name = "lblUserWorkplace";
            this.lblUserWorkplace.Size = new System.Drawing.Size(179, 26);
            this.lblUserWorkplace.TabIndex = 13;
            this.lblUserWorkplace.Text = "Workplace: None";
            // 
            // lstMessages
            // 
            this.lstMessages.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstMessages.FormattingEnabled = true;
            this.lstMessages.HorizontalScrollbar = true;
            this.lstMessages.ItemHeight = 25;
            this.lstMessages.Location = new System.Drawing.Point(1153, 149);
            this.lstMessages.Name = "lstMessages";
            this.lstMessages.Size = new System.Drawing.Size(663, 529);
            this.lstMessages.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1147, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 36);
            this.label4.TabIndex = 15;
            this.label4.Text = "Messages: ";
            // 
            // btnLogOut
            // 
            this.btnLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.Location = new System.Drawing.Point(1675, 900);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(141, 59);
            this.btnLogOut.TabIndex = 16;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnEditProfile
            // 
            this.btnEditProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditProfile.Location = new System.Drawing.Point(18, 710);
            this.btnEditProfile.Name = "btnEditProfile";
            this.btnEditProfile.Size = new System.Drawing.Size(182, 49);
            this.btnEditProfile.TabIndex = 17;
            this.btnEditProfile.Text = "Edit Profile";
            this.btnEditProfile.UseVisualStyleBackColor = true;
            this.btnEditProfile.Click += new System.EventHandler(this.btnEditProfile_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(18, 777);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(179, 35);
            this.btnRefresh.TabIndex = 18;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(18, 158);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 153);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // DatabaseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnEditProfile);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lstMessages);
            this.Controls.Add(this.lblUserWorkplace);
            this.Controls.Add(this.lblUserUniversity);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lstFriends);
            this.Controls.Add(this.lblUserCurrentCity);
            this.Controls.Add(this.lblHometown);
            this.Controls.Add(this.lblUserRelationshipStatus);
            this.Controls.Add(this.lblUserGender);
            this.Controls.Add(this.lblUserFullName);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblWelcomeName);
            this.Name = "DatabaseForm";
            this.Text = "Sample User Interface";
            this.Load += new System.EventHandler(this.DatabaseForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblWelcomeName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblUserFullName;
        private System.Windows.Forms.Label lblUserGender;
        private System.Windows.Forms.Label lblUserRelationshipStatus;
        private System.Windows.Forms.Label lblHometown;
        private System.Windows.Forms.Label lblUserCurrentCity;
        private System.Windows.Forms.ListBox lstFriends;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblUserUniversity;
        private System.Windows.Forms.Label lblUserWorkplace;
        private System.Windows.Forms.ListBox lstMessages;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnEditProfile;
        private System.Windows.Forms.Button btnRefresh;
    }
}

