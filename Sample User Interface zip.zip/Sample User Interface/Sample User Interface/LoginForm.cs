﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Sample_User_Interface
{


    public partial class LoginForm : Form
    {

        public static int currentUserID;


        public LoginForm()
        {
            InitializeComponent();
        }

        

        private void btnEnter_Click(object sender, EventArgs e)
        {

            if (txtUserID.Text == "")
            {
                MessageBox.Show("Please Enter Your UserID To Continue.");
            }
            else
            {
                currentUserID = Convert.ToInt32(txtUserID.Text);
                Hide();
                DatabaseForm databaseForm = new DatabaseForm();
                databaseForm.ShowDialog();
                databaseForm = null;
                Show();
                Hide();
            }

        }
    }
}
