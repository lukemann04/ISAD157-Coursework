﻿namespace Sample_User_Interface
{
    partial class FriendForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblFriendName = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblRelationshipStatus = new System.Windows.Forms.Label();
            this.lblHometown = new System.Windows.Forms.Label();
            this.lblCurrentCity = new System.Windows.Forms.Label();
            this.lblUniversity = new System.Windows.Forms.Label();
            this.lblWorkplace = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(115, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 153);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblFriendName
            // 
            this.lblFriendName.AutoSize = true;
            this.lblFriendName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFriendName.Location = new System.Drawing.Point(110, 211);
            this.lblFriendName.Name = "lblFriendName";
            this.lblFriendName.Size = new System.Drawing.Size(154, 29);
            this.lblFriendName.TabIndex = 1;
            this.lblFriendName.Text = "Friend Name";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.Location = new System.Drawing.Point(98, 283);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(66, 22);
            this.lblGender.TabIndex = 2;
            this.lblGender.Text = "gender";
            // 
            // lblRelationshipStatus
            // 
            this.lblRelationshipStatus.AutoSize = true;
            this.lblRelationshipStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRelationshipStatus.Location = new System.Drawing.Point(36, 338);
            this.lblRelationshipStatus.Name = "lblRelationshipStatus";
            this.lblRelationshipStatus.Size = new System.Drawing.Size(155, 22);
            this.lblRelationshipStatus.TabIndex = 3;
            this.lblRelationshipStatus.Text = "relationship status";
            // 
            // lblHometown
            // 
            this.lblHometown.AutoSize = true;
            this.lblHometown.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHometown.Location = new System.Drawing.Point(59, 391);
            this.lblHometown.Name = "lblHometown";
            this.lblHometown.Size = new System.Drawing.Size(92, 22);
            this.lblHometown.TabIndex = 4;
            this.lblHometown.Text = "hometown";
            // 
            // lblCurrentCity
            // 
            this.lblCurrentCity.AutoSize = true;
            this.lblCurrentCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentCity.Location = new System.Drawing.Point(53, 446);
            this.lblCurrentCity.Name = "lblCurrentCity";
            this.lblCurrentCity.Size = new System.Drawing.Size(98, 22);
            this.lblCurrentCity.TabIndex = 5;
            this.lblCurrentCity.Text = "current city";
            // 
            // lblUniversity
            // 
            this.lblUniversity.AutoSize = true;
            this.lblUniversity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUniversity.Location = new System.Drawing.Point(59, 501);
            this.lblUniversity.Name = "lblUniversity";
            this.lblUniversity.Size = new System.Drawing.Size(86, 22);
            this.lblUniversity.TabIndex = 6;
            this.lblUniversity.Text = "university";
            // 
            // lblWorkplace
            // 
            this.lblWorkplace.AutoSize = true;
            this.lblWorkplace.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorkplace.Location = new System.Drawing.Point(59, 550);
            this.lblWorkplace.Name = "lblWorkplace";
            this.lblWorkplace.Size = new System.Drawing.Size(91, 22);
            this.lblWorkplace.TabIndex = 7;
            this.lblWorkplace.Text = "workplace";
            // 
            // FriendForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 680);
            this.Controls.Add(this.lblWorkplace);
            this.Controls.Add(this.lblUniversity);
            this.Controls.Add(this.lblCurrentCity);
            this.Controls.Add(this.lblHometown);
            this.Controls.Add(this.lblRelationshipStatus);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lblFriendName);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FriendForm";
            this.Text = "Friend Details";
            this.Load += new System.EventHandler(this.FriendForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblFriendName;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblRelationshipStatus;
        private System.Windows.Forms.Label lblHometown;
        private System.Windows.Forms.Label lblCurrentCity;
        private System.Windows.Forms.Label lblUniversity;
        private System.Windows.Forms.Label lblWorkplace;
    }
}