﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Sample_User_Interface
{
    public partial class DatabaseForm : Form
    {
        public DatabaseForm()
        {
            InitializeComponent();
        }

        public int temp = LoginForm.currentUserID;

        public static string userFirstName;
        public static string userLastName;
        public static string userGender;
        public static string userRelationshipStaus;
        public static string userHometown;
        public static string userCurrentCity;
        public static string userUniversity;
        public static string userWorkplace;


        public static List<int> friendIDs = new List<int>();

        public static int selectedFriend;

        private void DatabaseForm_Load(object sender, EventArgs e)
        {

            #region User Profile

            string connectionString = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
            using (MySqlConnection connection =
                new MySqlConnection(connectionString))
            {

                string query = "SELECT user_firstName,user_lastName,user_gender,user_relationshipStatus,user_hometown,user_currentCity FROM isad157_lmann.user_table WHERE user_id=" + temp;

                connection.Open();

                MySqlCommand cmd = new MySqlCommand(query, connection);


                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();

                string currentUserName = "";
                string fullUserName = "";
                string currentUserGender = "";
                string currentUserRelationshipStatus = "";
                string currentUserHometown = "";
                string currentUserCurrentCity = "";

                while (dataReader.Read())
                {
                    currentUserName = Convert.ToString(dataReader.GetValue(0));
                    fullUserName = Convert.ToString(dataReader.GetValue(0)) + " " + Convert.ToString(dataReader.GetValue(1));
                    currentUserGender = Convert.ToString(dataReader.GetValue(2));
                    currentUserRelationshipStatus = Convert.ToString(dataReader.GetValue(3));
                    currentUserHometown = Convert.ToString(dataReader.GetValue(4));
                    currentUserCurrentCity = Convert.ToString(dataReader.GetValue(5));
                    userLastName = Convert.ToString(dataReader.GetValue(1));
                }
                dataReader.Close();


                lblWelcomeName.Text = currentUserName + ",";
                lblUserFullName.Text = fullUserName;
                lblUserGender.Text = "Gender: " + currentUserGender;
                lblUserRelationshipStatus.Text = "Relationship Status: " + currentUserRelationshipStatus;
                lblHometown.Text = "Hometown: " + currentUserHometown;
                lblUserCurrentCity.Text = "Current City: " + currentUserCurrentCity;

                userFirstName = currentUserName;
                userGender = currentUserGender;
                userRelationshipStaus = currentUserRelationshipStatus;
                userHometown = currentUserHometown;
                userCurrentCity = currentUserCurrentCity;



            } // End of using (MySqlConnection connection = ...


            #endregion


            #region Friends List

            string connectionString2 = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";



            using (MySqlConnection connection =
                new MySqlConnection(connectionString2))
            {

                string query = "SELECT friendships_userID2 FROM isad157_lmann.friendships_table WHERE friendships_userID1=" + temp;


                connection.Open();


                MySqlCommand cmd = new MySqlCommand(query, connection);


                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();

                string friendID = "";

                while (dataReader.Read())
                {
                    friendID = Convert.ToString(dataReader.GetValue(0));


                    friendIDs.Add(Convert.ToInt32(dataReader.GetValue(0)));





                    string connectionString3 = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
                    using (MySqlConnection connection3 =
                        new MySqlConnection(connectionString3))
                    {

                        string query3 = "SELECT user_firstName,user_lastName FROM isad157_lmann.user_table WHERE user_id=" + friendID;

                        connection3.Open();

                        MySqlCommand cmd3 = new MySqlCommand(query3, connection3);


                        MySqlDataReader dataReader2;
                        dataReader2 = cmd3.ExecuteReader();

                        string friendFirstName = "";
                        string friendLastName = "";


                        while (dataReader2.Read())
                        {
                            friendFirstName = Convert.ToString(dataReader2.GetValue(0));
                            friendLastName = Convert.ToString(dataReader2.GetValue(1));
                        }
                        dataReader2.Close();

                        string friendFullName = friendFirstName + " " + friendLastName;

                        lstFriends.Items.Add(friendFullName);


                    } // End of using (MySqlConnection connection = ...

                }
                dataReader.Close();

            } // End of using (MySqlConnection connection = ...
            #endregion


            #region User University
            string connectionString4 = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
            using (MySqlConnection connection =
                new MySqlConnection(connectionString4))
            {

                string query = "SELECT universities_universityName FROM isad157_lmann.universities_table WHERE universities_userID=" + temp;

                connection.Open();

                MySqlCommand cmd = new MySqlCommand(query, connection);


                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();

                string universityName = "";


                while (dataReader.Read())
                {
                    universityName = Convert.ToString(dataReader.GetValue(0));
                }
                dataReader.Close();

                lblUserUniversity.Text = "University: " + universityName;

                userUniversity = universityName;


            } // End of using (MySqlConnection connection = ...
            #endregion


            #region User Workplace
            string connectionString5 = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
            using (MySqlConnection connection =
                new MySqlConnection(connectionString5))
            {

                string query = "SELECT workplaces_workplaceName FROM isad157_lmann.workplaces_table WHERE workplaces_userID=" + temp;

                connection.Open();

                MySqlCommand cmd = new MySqlCommand(query, connection);


                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();

                string workplaceName = "";


                while (dataReader.Read())
                {
                    workplaceName = Convert.ToString(dataReader.GetValue(0));
                }
                dataReader.Close();

                lblUserWorkplace.Text = "Workplace: " + workplaceName;

                userWorkplace = workplaceName;


            } // End of using (MySqlConnection connection = ...
            #endregion


            #region Message List

            string connectionString6 = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";



            using (MySqlConnection connection =
                new MySqlConnection(connectionString6))
            {

                string query = "SELECT messages_userID2,messages_messageDateAndTime,messages_messageText FROM isad157_lmann.messages_table WHERE messages_userID1=" + temp;


                connection.Open();


                MySqlCommand cmd = new MySqlCommand(query, connection);


                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();

                string messageFriendID = "";
                string messageDateAndTime = "";
                string messageText = "";

                while (dataReader.Read())
                {
                    messageFriendID = Convert.ToString(dataReader.GetValue(0));
                    messageDateAndTime = Convert.ToString(dataReader.GetValue(1));
                    messageText = Convert.ToString(dataReader.GetValue(2));

                    string connectionString3 = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
                    using (MySqlConnection connection3 =
                        new MySqlConnection(connectionString3))
                    {

                        string query3 = "SELECT user_firstName,user_lastName FROM isad157_lmann.user_table WHERE user_id=" + messageFriendID;

                        connection3.Open();

                        MySqlCommand cmd3 = new MySqlCommand(query3, connection3);


                        MySqlDataReader dataReader2;
                        dataReader2 = cmd3.ExecuteReader();

                        string messageFriendFirstName = "";
                        string messageFriendLastName = "";


                        while (dataReader2.Read())
                        {
                            messageFriendFirstName = Convert.ToString(dataReader2.GetValue(0));
                            messageFriendLastName = Convert.ToString(dataReader2.GetValue(1));
                        }
                        dataReader2.Close();

                        string messageFriendFullName = messageFriendFirstName + " " + messageFriendLastName;


                        lstMessages.Items.Add(messageFriendFullName + " " + "Sent: " + messageDateAndTime + "  " + messageText);

                    } // End of using (MySqlConnection connection = ...
                }
                dataReader.Close();

            } // End of using (MySqlConnection connection = ...
            #endregion

            this.WindowState = FormWindowState.Normal;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Bounds = Screen.PrimaryScreen.Bounds;

            pictureBox1.Image = new Bitmap(@"default-profile.png");

            lstFriends.DoubleClick += new EventHandler(lstFriends_DoubleClick);        
        }

        private void lstFriends_DoubleClick(object sender, EventArgs e)
        {
            if (lstFriends.SelectedItem != null)
            {
                selectedFriend = lstFriends.SelectedIndex;

                FriendForm friendForm = new FriendForm();
                friendForm.ShowDialog();
                friendForm = null;
                Show();
            }
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {

            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Dispose();

        }

        private void btnEditProfile_Click(object sender, EventArgs e)
        {
            EditForm editForm = new EditForm();
            editForm.ShowDialog();
            editForm = null;
            Show();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {

            DatabaseForm databaseForm = new DatabaseForm();
            databaseForm.Show();
            this.Dispose();
        }
    }
}
