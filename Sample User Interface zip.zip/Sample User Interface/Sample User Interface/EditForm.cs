﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Sample_User_Interface
{
    public partial class EditForm : Form
    {
        public EditForm()
        {
            InitializeComponent();
        }

        public int temp = LoginForm.currentUserID;

        public static string newUserFirstName;
        public static string newUserLastName;
        public static string newUserGender;
        public static string newUserRelationshipStaus;
        public static string newUserHometown;
        public static string newUserCurrentCity;
        public static string newUserUniversity;
        public static string newUserWorkplace;

        public string tempUserFirstName = DatabaseForm.userFirstName;
        public string tempUserLastName = DatabaseForm.userLastName;
        public string tempUserGender = DatabaseForm.userGender;
        public string tempUserRelationshipStatus = DatabaseForm.userRelationshipStaus;
        public string tempUserHometown = DatabaseForm.userHometown;
        public string tempUserCurrentCity = DatabaseForm.userCurrentCity;
        public string tempUserUniversity = DatabaseForm.userUniversity;
        public string tempUserWorkplace = DatabaseForm.userWorkplace;

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void EditForm_Load(object sender, EventArgs e)
        {
            txtFirstName.Text = tempUserFirstName;
            txtLastName.Text = tempUserLastName;
            comboGender.Text = tempUserGender;
            toolStripMenuItem1.Text = tempUserGender;
            comboRelationshipStatus.Text = tempUserRelationshipStatus;
            toolStripMenuItem2.Text = tempUserRelationshipStatus;
            txtHometown.Text = tempUserHometown;
            txtCurrentCity.Text = tempUserCurrentCity;
            txtUniversity.Text = tempUserUniversity;
            txtWorkplace.Text = tempUserWorkplace;
        }

        #region Gender Selection
        private void maleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboGender.Text = "Male";
            toolStripMenuItem1.Text = "Male";
        }

        private void femaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboGender.Text = "Female";
            toolStripMenuItem1.Text = "Female";
        }
        #endregion

        #region Relationship Selection
        private void singleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboRelationshipStatus.Text = "Single";
            toolStripMenuItem2.Text = "Single";
        }

        private void inARelationshipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboRelationshipStatus.Text = "In a Relationship";
            toolStripMenuItem2.Text = "In a Relationship";
        }

        private void engagedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboRelationshipStatus.Text = "Engaged";
            toolStripMenuItem2.Text = "Engaged";
        }

        private void marriedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboRelationshipStatus.Text = "Married";
            toolStripMenuItem2.Text = "Married";
        }

        #endregion

        #region Submit Button

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string connectionString = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
            using (MySqlConnection connection =
                new MySqlConnection(connectionString))
            {

                string query = "UPDATE isad157_lmann.user_table SET user_firstName='"+ txtFirstName.Text +"',user_lastName='"+ txtLastName.Text +"',user_hometown='"+ txtHometown.Text +"',user_gender='"+ comboGender.Text +"',user_RelationshipStatus='"+ comboRelationshipStatus.Text +"',user_currentCity='"+ txtCurrentCity.Text +"' WHERE user_id=" + temp;

                connection.Open();

                MySqlCommand cmd = new MySqlCommand(query, connection);


                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();


                while (dataReader.Read())
                {
                    newUserFirstName = txtFirstName.Text;
                    newUserLastName = txtLastName.Text;
                    newUserHometown = txtHometown.Text;
                    newUserGender = comboGender.Text;
                    newUserRelationshipStaus = comboRelationshipStatus.Text;
                    newUserCurrentCity = txtCurrentCity.Text;
                    newUserUniversity = txtUniversity.Text;
                    newUserWorkplace = txtWorkplace.Text;
                }
                dataReader.Close();

                MessageBox.Show("Details Updated Successfully");

                DatabaseForm.userFirstName = newUserFirstName;
                DatabaseForm.userLastName = newUserLastName;
                DatabaseForm.userHometown = newUserHometown;
                DatabaseForm.userGender = newUserGender;
                DatabaseForm.userRelationshipStaus = newUserRelationshipStaus;
                DatabaseForm.userCurrentCity = newUserCurrentCity;
                DatabaseForm.userUniversity = newUserUniversity;
                DatabaseForm.userWorkplace = newUserWorkplace;

                

                Close();



            } // End of using (MySqlConnection connection = ...
            #endregion
        }
    }
}
