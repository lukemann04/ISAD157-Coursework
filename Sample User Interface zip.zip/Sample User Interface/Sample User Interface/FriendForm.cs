﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Sample_User_Interface
{
    public partial class FriendForm : Form
    {
        public FriendForm()
        {
            InitializeComponent();
        }

        private void FriendForm_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = new Bitmap(@"default-profile.png");

            int i;
            i = DatabaseForm.selectedFriend;
            int j;
            j = DatabaseForm.friendIDs[i];

            #region Friend Details
            string connectionString = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
            using (MySqlConnection connection =
                new MySqlConnection(connectionString))
            {

                string query = "SELECT user_firstName,user_lastName,user_gender,user_relationshipStatus,user_hometown,user_currentCity FROM isad157_lmann.user_table WHERE user_id=" + j;

                connection.Open();

                MySqlCommand cmd = new MySqlCommand(query, connection);



                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();

                string fullUserName = "";
                string currentUserGender = "";
                string currentUserRelationshipStatus = "";
                string currentUserHometown = "";
                string currentUserCurrentCity = "";

                while (dataReader.Read())
                {
                    fullUserName = Convert.ToString(dataReader.GetValue(0)) + " " + Convert.ToString(dataReader.GetValue(1));
                    currentUserGender = Convert.ToString(dataReader.GetValue(2));
                    currentUserRelationshipStatus = Convert.ToString(dataReader.GetValue(3));
                    currentUserHometown = Convert.ToString(dataReader.GetValue(4));
                    currentUserCurrentCity = Convert.ToString(dataReader.GetValue(5));
                }
                dataReader.Close();

                lblFriendName.Text = fullUserName;
                lblGender.Text = "Gender: " + currentUserGender;
                lblRelationshipStatus.Text = "Relationship Status: " + currentUserRelationshipStatus;
                lblHometown.Text = "Hometown: " + currentUserHometown;
                lblCurrentCity.Text = "Current City: " + currentUserCurrentCity;



            } // End of using (MySqlConnection connection = ...
            #endregion


            #region Friend University
            string connectionString4 = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
            using (MySqlConnection connection =
                new MySqlConnection(connectionString4))
            {

                string query = "SELECT universities_universityName FROM isad157_lmann.universities_table WHERE universities_userID=" + j;

                connection.Open();

                MySqlCommand cmd = new MySqlCommand(query, connection);


                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();

                string universityName = "";


                while (dataReader.Read())
                {
                    universityName = Convert.ToString(dataReader.GetValue(0));
                }
                dataReader.Close();

                lblUniversity.Text = "University: " + universityName;


            } // End of using (MySqlConnection connection = ...
            #endregion


            #region Friend Workplace
            string connectionString5 = "SERVER=" + DBConnect.SERVER + ";" +
                "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                DBConnect.USER_NAME + ";" + "PASSWORD=" +
                DBConnect.PASSWORD + ";" + "SslMode=" +
                DBConnect.SslMode + ";";
            using (MySqlConnection connection =
                new MySqlConnection(connectionString5))
            {

                string query = "SELECT workplaces_workplaceName FROM isad157_lmann.workplaces_table WHERE workplaces_userID=" + j;

                connection.Open();

                MySqlCommand cmd = new MySqlCommand(query, connection);



                MySqlDataReader dataReader;
                dataReader = cmd.ExecuteReader();

                string workplaceName = "";


                while (dataReader.Read())
                {
                    workplaceName = Convert.ToString(dataReader.GetValue(0));
                }
                dataReader.Close();

                lblWorkplace.Text = "Workplace: " + workplaceName;

            } // End of using (MySqlConnection connection = ...
            #endregion
        }
    }
}
